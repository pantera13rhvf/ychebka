# Библиотека колледжа — учёт книжного фонда и выдачи

Учебный Django-проект: учёт книжного фонда библиотеки колледжа, читателей и выдачи
литературы. Реализованы админ-панель, REST API с JWT-авторизацией и аналитические отчёты.

## Стек

| Компонент | Версия |
|---|---|
| Python | 3.11+ |
| Django | 5.1.4 |
| Django REST Framework | 3.15.2 |
| djangorestframework-simplejwt | 5.3.1 |
| django-filter | 24.3 |
| django-cors-headers | 4.4.0 |
| БД | SQLite (по умолчанию) / PostgreSQL (опционально) |

## Структура

```
Библиотека_college/
├── manage.py
├── seed.py                 # демонстрационные данные (идемпотентно)
├── requirements.txt
├── .env.example
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
└── apps/
    ├── accounts/           # сотрудники, JWT-вход
    ├── catalog/            # авторы, категории, книги
    ├── readers/            # читатели
    ├── loans/              # выдачи и возвраты
    └── reports/            # KPI, динамика, топ книг, состояние фонда
```

В каждом приложении: `models.py`, `admin.py`, `serializers.py`, `views.py`, `urls.py`,
`apps.py`, `migrations/`.

## Быстрый старт

```powershell
cd "Проекты\Библиотека_college"
python -m pip install -r requirements.txt

python manage.py makemigrations
python manage.py migrate
python seed.py

python manage.py runserver 127.0.0.1:8022
```

Админка: <http://127.0.0.1:8022/admin/> — `admin` / `admin12345`.

## Данные для входа

| Логин | Пароль | Роль |
|---|---|---|
| `admin` | `admin12345` | Администратор (суперпользователь) |
| `librarian` | `library2024` | Библиотекарь |
| `manager` | `library2024` | Заведующий |

## API

Базовый префикс — `/api/`. Все эндпоинты, кроме входа и обновления токена, требуют
заголовок `Authorization: Bearer <access>`.

| Метод | Эндпоинт | Назначение |
|---|---|---|
| POST | `/api/auth/login/` | Вход, возвращает `access`, `refresh`, профиль |
| POST | `/api/auth/refresh/` | Обновление access-токена |
| GET | `/api/auth/me/` | Профиль текущего сотрудника |
| GET/POST | `/api/books/` | Список и создание книг |
| GET/PUT/PATCH/DELETE | `/api/books/{id}/` | Карточка книги |
| GET | `/api/books/{id}/status/` | Актуальный статус экземпляров |
| GET/POST | `/api/authors/`, `/api/categories/` | Справочники |
| GET/POST | `/api/readers/` | Читатели |
| GET/PUT/PATCH/DELETE | `/api/readers/{id}/` | Карточка читателя |
| GET/POST | `/api/loans/` | Выдачи (создание сразу списывает экземпляр) |
| GET/PUT/PATCH/DELETE | `/api/loans/{id}/` | Карточка выдачи |
| POST | `/api/loans/{id}/return/` | Отметить возврат |
| GET | `/api/reports/kpi/?days=30` | KPI за период |
| GET | `/api/reports/issues/?days=30` | Выдачи и возвраты по дням |
| GET | `/api/reports/top-books/?limit=5` | Топ книг по выдачам |
| GET | `/api/reports/stock/` | Состояние фонда |

Пагинация — 20 записей на страницу (`?page=2`). Фильтры: `?status=`, `?category=`,
`?author=`, `?reader=`, `?book=`, `?overdue=1`. Поиск: `?search=` (название, ISBN,
ФИО читателя). Сортировка: `?ordering=`.

### Пример запроса

```powershell
$body = @{ username = "admin"; password = "admin12345" } | ConvertTo-Json
$token = (Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8022/api/auth/login/ `
    -ContentType "application/json" -Body $body).access
Invoke-RestMethod -Uri http://127.0.0.1:8022/api/books/ -Headers @{ Authorization = "Bearer $token" }
```

## Модели

* **accounts.User** — сотрудник: ФИО, должность (`admin` / `librarian` / `manager`), телефон.
* **catalog.Author**, **catalog.Category** — справочники авторов и разделов фонда.
* **catalog.Book** — книга: ISBN (уникальный), автор и категория (`PROTECT`), издательство,
  год, страницы, цена, всего и доступно экземпляров, статус, описание. Метод
  `recalc_status()` пересчитывает статус: `out` при 0 доступных, `limited` при 1–2,
  иначе `available`.
* **readers.Reader** — читатель: ФИО, номер билета (уникальный), контакты, дата рождения,
  блокировка, ответственный сотрудник (`SET_NULL`).
* **loans.Loan** — выдача: читатель (`CASCADE`), книга (`PROTECT`), кто выдал (`PROTECT`),
  даты выдачи/срока/возврата, статус, комментарий. `issue()` списывает экземпляр,
  `return_book()` возвращает его в фонд, `is_overdue` показывает просрочку.

## Отчёты

`apps/reports/services.py`, класс `ReportService`:

* `kpi(days=30)` → `{issued, returned, overdue, fund_size, period_days}`;
* `issues_by_day(days=30)` → список `{date, issued, returned}` за каждый день периода;
* `top_books(limit=5)` → книги, отсортированные по числу выдач;
* `stock_status()` → экземпляры фонда и количество книг по статусам.

## Тесты

```powershell
python manage.py test
```

Покрыты выдача и возврат (изменение `available_copies`), запрет выдачи при нулевом
остатке, пересчёт статуса книги, определение просрочки, KPI и отчёты, а также
проверка доступа к API.

## Настройки окружения

Переменные читаются через `os.getenv()`; список — в `.env.example`.
Ключевые:

* `DJANGO_SECRET_KEY`, `DJANGO_DEBUG`, `DJANGO_ALLOWED_HOSTS`;
* `POSTGRES_HOST` — если **не задан**, используется SQLite (`db.sqlite3`);
  если задан, включается PostgreSQL (`POSTGRES_DB`, `POSTGRES_USER`,
  `POSTGRES_PASSWORD`, `POSTGRES_PORT`);
* `CORS_ALLOWED_ORIGINS` — источники фронтенда через запятую;
* `JWT_ACCESS_MINUTES`, `JWT_REFRESH_DAYS`.

## Админка

`admin.site.site_header` = «Библиотека колледжа: администрирование»,
`site_title` = «Библиотека колледжа», `index_title` = «Управление книжным фондом и выдачей».

Для книг в списке доступно быстрое редактирование `available_copies` и `status`,
для выдач — действие «Отметить возврат».
