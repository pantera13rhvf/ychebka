from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ("username", "full_name", "position", "phone", "is_staff", "is_active")
    list_filter = ("position", "is_staff", "is_active")
    search_fields = ("username", "full_name", "phone", "email")
    ordering = ("full_name", "username")

    fieldsets = BaseUserAdmin.fieldsets + (
        (
            "Профиль сотрудника",
            {"fields": ("full_name", "position", "phone")},
        ),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        (
            "Профиль сотрудника",
            {"fields": ("full_name", "position", "phone")},
        ),
    )
