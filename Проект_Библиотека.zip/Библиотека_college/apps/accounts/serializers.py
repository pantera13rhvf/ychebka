from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import User


class UserSerializer(serializers.ModelSerializer):
    position_display = serializers.CharField(source="get_position_display", read_only=True)

    class Meta:
        model = User
        fields = (
            "id",
            "username",
            "full_name",
            "position",
            "position_display",
            "phone",
            "email",
            "is_staff",
            "is_active",
        )
        read_only_fields = ("id",)


class LoginSerializer(TokenObtainPairSerializer):
    """Логин по username/паролю с расширенным ответом (JWT + профиль)."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["username"] = user.username
        token["full_name"] = user.full_name
        token["position"] = user.position
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        data["user"] = UserSerializer(self.user).data
        return data
