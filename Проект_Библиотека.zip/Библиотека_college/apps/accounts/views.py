from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from .serializers import LoginSerializer, UserSerializer


class LoginView(TokenObtainPairView):
    """POST /api/auth/login/ — получить access и refresh токены."""

    permission_classes = (permissions.AllowAny,)
    serializer_class = LoginSerializer


class RefreshView(TokenRefreshView):
    """POST /api/auth/refresh/ — обновить access по refresh."""

    permission_classes = (permissions.AllowAny,)


class MeView(generics.GenericAPIView):
    """GET /api/auth/me/ — профиль текущего сотрудника."""

    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = UserSerializer

    def get(self, request, *args, **kwargs):
        return Response(UserSerializer(request.user).data)
