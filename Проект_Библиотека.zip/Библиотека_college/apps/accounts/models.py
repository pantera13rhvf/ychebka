from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Сотрудник библиотеки колледжа."""

    class Position(models.TextChoices):
        ADMIN = "admin", "Администратор"
        LIBRARIAN = "librarian", "Библиотекарь"
        MANAGER = "manager", "Заведующий"

    full_name = models.CharField("ФИО", max_length=150, blank=True)
    position = models.CharField(
        "Должность",
        max_length=20,
        choices=Position.choices,
        default=Position.LIBRARIAN,
    )
    phone = models.CharField("Телефон", max_length=20, blank=True)

    class Meta:
        verbose_name = "Сотрудник"
        verbose_name_plural = "Сотрудники"
        ordering = ["full_name", "username"]

    def __str__(self):
        return self.full_name or self.username

    @property
    def short_name(self):
        """Фамилия и инициалы — для компактного вывода в списках."""
        parts = self.full_name.split()
        if len(parts) >= 2:
            return f"{parts[0]} {'.'.join(p[0] for p in parts[1:3])}."
        return self.full_name or self.username
