from django.urls import path

from .views import IssuesView, KpiView, StockView, TopBooksView

app_name = "reports"

urlpatterns = [
    path("kpi/", KpiView.as_view(), name="kpi"),
    path("issues/", IssuesView.as_view(), name="issues"),
    path("top-books/", TopBooksView.as_view(), name="top-books"),
    path("stock/", StockView.as_view(), name="stock"),
]
