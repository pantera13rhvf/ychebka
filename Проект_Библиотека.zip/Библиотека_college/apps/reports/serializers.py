from rest_framework import serializers


class KpiQuerySerializer(serializers.Serializer):
    days = serializers.IntegerField(min_value=1, max_value=365, default=30, required=False)


class IssuesQuerySerializer(serializers.Serializer):
    days = serializers.IntegerField(min_value=1, max_value=365, default=30, required=False)


class TopBooksQuerySerializer(serializers.Serializer):
    limit = serializers.IntegerField(min_value=1, max_value=50, default=5, required=False)


class KpiSerializer(serializers.Serializer):
    issued = serializers.IntegerField()
    returned = serializers.IntegerField()
    overdue = serializers.IntegerField()
    fund_size = serializers.IntegerField()
    period_days = serializers.IntegerField()


class IssueByDaySerializer(serializers.Serializer):
    date = serializers.DateField()
    issued = serializers.IntegerField()
    returned = serializers.IntegerField()


class TopBookSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    title = serializers.CharField()
    author = serializers.CharField()
    category = serializers.CharField()
    loan_count = serializers.IntegerField()
    total_copies = serializers.IntegerField()
    available_copies = serializers.IntegerField()


class StockStatusItemSerializer(serializers.Serializer):
    status = serializers.CharField()
    label = serializers.CharField()
    count = serializers.IntegerField()


class StockStatusSerializer(serializers.Serializer):
    total_copies = serializers.IntegerField()
    available_copies = serializers.IntegerField()
    issued_copies = serializers.IntegerField()
    books_total = serializers.IntegerField()
    by_status = StockStatusItemSerializer(many=True)
