from datetime import timedelta
from decimal import Decimal

from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.catalog.models import Author, Book, Category
from apps.loans.models import Loan
from apps.readers.models import Reader

from .services import ReportService


class ReportTestBase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.staff = User.objects.create_user(
            username="manager",
            password="library2024",
            full_name="Кузнецова Ирина Петровна",
            position=User.Position.MANAGER,
        )
        cls.author = Author.objects.create(first_name="Фёдор", last_name="Достоевский", country="Россия")
        cls.category = Category.objects.create(name="Русская классика", slug="russkaya-klassika")

        cls.book_a = Book.objects.create(
            title="Книга А",
            isbn="978-5-04-100000-1",
            author=cls.author,
            category=cls.category,
            total_copies=5,
            available_copies=3,
            year=2020,
            pages=300,
            price=Decimal("500.00"),
        )
        cls.book_b = Book.objects.create(
            title="Книга Б",
            isbn="978-5-04-100000-2",
            author=cls.author,
            category=cls.category,
            total_copies=2,
            available_copies=1,
            year=2021,
            pages=200,
            price=Decimal("450.00"),
        )
        cls.book_c = Book.objects.create(
            title="Книга В",
            isbn="978-5-04-100000-3",
            author=cls.author,
            category=cls.category,
            total_copies=3,
            available_copies=3,
            year=2022,
            pages=150,
            price=Decimal("300.00"),
        )

        cls.reader_one = Reader.objects.create(full_name="Иванова Мария Сергеевна", ticket_number="Ч-1")
        cls.reader_two = Reader.objects.create(full_name="Петров Алексей Николаевич", ticket_number="Ч-2")

        now = timezone.now()
        today = timezone.localdate()

        def loan(reader, book, issued_days_ago, due_in_days, returned_days_ago=None, status=Loan.Status.ACTIVE):
            return Loan.objects.create(
                reader=reader,
                book=book,
                issued_by=cls.staff,
                issued_at=now - timedelta(days=issued_days_ago),
                due_date=today + timedelta(days=due_in_days),
                returned_at=now - timedelta(days=returned_days_ago) if returned_days_ago is not None else None,
                status=status,
            )

        # Внутри 30-дневного окна
        cls.loan_fresh = loan(cls.reader_one, cls.book_a, 5, 9)
        cls.loan_overdue = loan(cls.reader_two, cls.book_a, 10, -3)
        cls.loan_returned = loan(
            cls.reader_one,
            cls.book_b,
            12,
            -2,
            returned_days_ago=1,
            status=Loan.Status.RETURNED,
        )
        # Вне 30-дневного окна, но внутри 60-дневного
        cls.loan_old = loan(
            cls.reader_two,
            cls.book_b,
            45,
            -31,
            returned_days_ago=40,
            status=Loan.Status.RETURNED,
        )
        # Активная выдача без просрочки
        cls.loan_active = loan(cls.reader_two, cls.book_c, 20, 4)


class ReportServiceTests(ReportTestBase):
    def test_kpi_returns_all_required_keys(self):
        """KPI содержит issued, returned, overdue, fund_size, period_days."""
        data = ReportService.kpi()

        self.assertEqual(
            set(data),
            {"issued", "returned", "overdue", "fund_size", "period_days"},
        )
        self.assertEqual(data["period_days"], 30)

    def test_kpi_counts_issued_in_period(self):
        """KPI считает выдачи за период (30 дней)."""
        data = ReportService.kpi(days=30)
        # В окне: 5, 10, 12 и 20 дней назад = 4
        self.assertEqual(data["issued"], 4)

        wide = ReportService.kpi(days=60)
        self.assertEqual(wide["issued"], 5, "Выдача 45-дневной давности входит только в 60-дневный период")

    def test_kpi_counts_returned_in_period(self):
        """KPI считает возвраты за период."""
        self.assertEqual(ReportService.kpi(days=30)["returned"], 1)
        self.assertEqual(ReportService.kpi(days=60)["returned"], 2)

    def test_kpi_counts_overdue_loans(self):
        """KPI считает просроченные невозвращённые выдачи."""
        self.assertEqual(ReportService.kpi(days=30)["overdue"], 1)

    def test_kpi_fund_size(self):
        """fund_size — суммарное число экземпляров фонда."""
        self.assertEqual(ReportService.kpi()["fund_size"], 10)

    def test_issues_by_day_structure_and_totals(self):
        """issues_by_day отдаёт по одной строке на каждый день периода."""
        rows = ReportService.issues_by_day(days=7)

        self.assertEqual(len(rows), 7)
        self.assertEqual(rows[-1]["date"], timezone.localdate().isoformat())
        # За 7 дней: одна выдача (5 дней назад) и один возврат (1 день назад).
        self.assertEqual(sum(row["issued"] for row in rows), 1)
        self.assertEqual(sum(row["returned"] for row in rows), 1)

        month_rows = ReportService.issues_by_day(days=30)
        self.assertEqual(len(month_rows), 30)
        self.assertEqual(sum(row["issued"] for row in month_rows), 4)

    def test_top_books_sorted_and_limited(self):
        """top_books сортирует по числу выдач и уважает лимит."""
        top = ReportService.top_books(limit=2)

        self.assertEqual(len(top), 2)
        self.assertEqual(top[0]["title"], "Книга А")
        self.assertEqual(top[0]["loan_count"], 2)
        self.assertGreaterEqual(top[0]["loan_count"], top[1]["loan_count"])

        self.assertEqual(len(ReportService.top_books(limit=10)), 3)

    def test_stock_status_totals(self):
        """stock_status суммирует экземпляры и группирует книги по статусам."""
        data = ReportService.stock_status()

        self.assertEqual(data["total_copies"], 10)
        self.assertEqual(data["available_copies"], 7)
        self.assertEqual(data["issued_copies"], 3)
        self.assertEqual(data["books_total"], 3)

        by_status = {row["status"]: row["count"] for row in data["by_status"]}
        self.assertEqual(set(by_status), {choice for choice, _ in Book.Status.choices})
        self.assertEqual(by_status["available"], 2)
        self.assertEqual(by_status["limited"], 1)
        self.assertEqual(by_status["out"], 0)


class ReportApiTests(ReportTestBase):
    def setUp(self):
        self.client = APIClient()
        self.client.force_authenticate(user=self.staff)

    def test_kpi_endpoint(self):
        """GET /api/reports/kpi/ доступен сотруднику."""
        response = self.client.get("/api/reports/kpi/?days=30")

        self.assertEqual(response.status_code, 200, response.content)
        payload = response.json()
        self.assertEqual(payload["issued"], 4)
        self.assertEqual(payload["period_days"], 30)

    def test_reports_require_authentication(self):
        """Отчёты закрыты авторизацией."""
        anonymous = APIClient()
        self.assertEqual(anonymous.get("/api/reports/kpi/").status_code, 401)
        self.assertEqual(anonymous.get("/api/reports/stock/").status_code, 401)

    def test_stock_endpoint(self):
        response = self.client.get("/api/reports/stock/")

        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json()["total_copies"], 10)

    def test_kpi_rejects_invalid_days(self):
        """days=0 отклоняется валидацией запроса."""
        self.assertEqual(self.client.get("/api/reports/kpi/?days=0").status_code, 400)
