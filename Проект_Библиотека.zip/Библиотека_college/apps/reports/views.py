from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import (
    IssuesQuerySerializer,
    KpiQuerySerializer,
    KpiSerializer,
    TopBooksQuerySerializer,
)
from .services import ReportService


class BaseReportView(APIView):
    permission_classes = (IsAuthenticated,)

    def _query(self, serializer_class, request):
        serializer = serializer_class(data=request.query_params)
        serializer.is_valid(raise_exception=True)
        return serializer.validated_data


class KpiView(BaseReportView):
    """GET /api/reports/kpi/?days=30 — ключевые показатели."""

    def get(self, request):
        params = self._query(KpiQuerySerializer, request)
        data = ReportService.kpi(days=params.get("days", 30))
        return Response(KpiSerializer(data).data)


class IssuesView(BaseReportView):
    """GET /api/reports/issues/?days=30 — выдачи и возвраты по дням."""

    def get(self, request):
        params = self._query(IssuesQuerySerializer, request)
        return Response(ReportService.issues_by_day(days=params.get("days", 30)))


class TopBooksView(BaseReportView):
    """GET /api/reports/top-books/?limit=5 — самые популярные книги."""

    def get(self, request):
        params = self._query(TopBooksQuerySerializer, request)
        return Response(ReportService.top_books(limit=params.get("limit", 5)))


class StockView(BaseReportView):
    """GET /api/reports/stock/ — состояние книжного фонда."""

    def get(self, request):
        return Response(ReportService.stock_status())
