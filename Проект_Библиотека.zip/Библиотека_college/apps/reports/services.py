"""Сервис аналитики библиотеки: KPI, динамика выдач, топ книг, состояние фонда."""
from datetime import timedelta

from django.db.models import Count, Sum
from django.db.models.functions import Coalesce, TruncDate
from django.utils import timezone

from apps.catalog.models import Book
from apps.loans.models import Loan

MONTH_DAYS = 30


class ReportService:
    """Расчёт показателей для дашборда библиотеки."""

    @staticmethod
    def kpi(days: int = MONTH_DAYS) -> dict:
        """Ключевые показатели за период (по умолчанию 30 дней)."""
        days = int(days or MONTH_DAYS)
        since = timezone.now() - timedelta(days=days)

        issued = Loan.objects.filter(issued_at__gte=since).count()
        returned = Loan.objects.filter(
            returned_at__isnull=False, returned_at__gte=since
        ).count()
        overdue = Loan.objects.filter(
            returned_at__isnull=True, due_date__lt=timezone.localdate()
        ).count()
        fund_size = Book.objects.aggregate(total=Coalesce(Sum("total_copies"), 0))["total"]

        return {
            "issued": issued,
            "returned": returned,
            "overdue": overdue,
            "fund_size": fund_size,
            "period_days": days,
        }

    @staticmethod
    def issues_by_day(days: int = MONTH_DAYS) -> list:
        """Выдачи и возвраты по дням за период, включая дни без операций."""
        days = int(days or MONTH_DAYS)
        today = timezone.localdate()
        start = today - timedelta(days=days - 1)

        issued_rows = (
            Loan.objects.filter(issued_at__date__gte=start)
            .order_by()
            .annotate(day=TruncDate("issued_at"))
            .values("day")
            .annotate(total=Count("id"))
        )
        returned_rows = (
            Loan.objects.filter(returned_at__date__gte=start)
            .order_by()
            .annotate(day=TruncDate("returned_at"))
            .values("day")
            .annotate(total=Count("id"))
        )

        issued_map = {row["day"]: row["total"] for row in issued_rows}
        returned_map = {row["day"]: row["total"] for row in returned_rows}

        result = []
        for offset in range(days):
            day = start + timedelta(days=offset)
            result.append(
                {
                    "date": day.isoformat(),
                    "issued": issued_map.get(day, 0),
                    "returned": returned_map.get(day, 0),
                }
            )
        return result

    @staticmethod
    def top_books(limit: int = 5) -> list:
        """Самые востребованные книги по числу выдач."""
        limit = int(limit or 5)
        books = (
            Book.objects.select_related("author", "category")
            .order_by()
            .annotate(loan_count=Count("loans"))
            .filter(loan_count__gt=0)
            .order_by("-loan_count", "title")[:limit]
        )
        return [
            {
                "id": book.id,
                "title": book.title,
                "author": str(book.author),
                "category": book.category.name,
                "loan_count": book.loan_count,
                "total_copies": book.total_copies,
                "available_copies": book.available_copies,
            }
            for book in books
        ]

    @staticmethod
    def stock_status() -> dict:
        """Состояние книжного фонда: экземпляры и количество книг по статусам."""
        totals = Book.objects.aggregate(
            total_copies=Coalesce(Sum("total_copies"), 0),
            available_copies=Coalesce(Sum("available_copies"), 0),
        )
        total_copies = totals["total_copies"]
        available_copies = totals["available_copies"]

        counts = {
            row["status"]: row["total"]
            for row in Book.objects.order_by().values("status").annotate(total=Count("id"))
        }
        by_status = [
            {
                "status": value,
                "label": label,
                "count": counts.get(value, 0),
            }
            for value, label in Book.Status.choices
        ]

        return {
            "total_copies": total_copies,
            "available_copies": available_copies,
            "issued_copies": max(total_copies - available_copies, 0),
            "books_total": sum(counts.values()),
            "by_status": by_status,
        }
