from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils import timezone


class Author(models.Model):
    """Автор книги."""

    first_name = models.CharField("Имя", max_length=100)
    last_name = models.CharField("Фамилия", max_length=100)
    country = models.CharField("Страна", max_length=100, blank=True)

    class Meta:
        verbose_name = "Автор"
        verbose_name_plural = "Авторы"
        ordering = ["last_name", "first_name"]
        unique_together = ("first_name", "last_name")

    def __str__(self):
        return f"{self.last_name} {self.first_name}".strip()

    @property
    def full_name(self):
        return str(self)


class Category(models.Model):
    """Раздел книжного фонда."""

    name = models.CharField("Название", max_length=100, unique=True)
    slug = models.SlugField("Слаг", max_length=100, unique=True)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"
        ordering = ["name"]

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("catalog:category-detail", args=[self.pk])


class Book(models.Model):
    """Книга книжного фонда колледжа."""

    class Status(models.TextChoices):
        AVAILABLE = "available", "Доступна"
        LIMITED = "limited", "Осталось мало"
        OUT = "out", "Выданы все"

    LOW_STOCK_THRESHOLD = 2

    title = models.CharField("Название", max_length=255, db_index=True)
    isbn = models.CharField("ISBN", max_length=20, unique=True)
    author = models.ForeignKey(
        Author,
        verbose_name="Автор",
        on_delete=models.PROTECT,
        related_name="books",
    )
    category = models.ForeignKey(
        Category,
        verbose_name="Категория",
        on_delete=models.PROTECT,
        related_name="books",
    )
    publisher = models.CharField("Издательство", max_length=150, blank=True)
    year = models.PositiveIntegerField(
        "Год издания",
        validators=[MinValueValidator(1400), MaxValueValidator(2100)],
        default=2020,
    )
    pages = models.PositiveIntegerField(
        "Страниц", default=100, validators=[MinValueValidator(1)]
    )
    price = models.DecimalField("Цена, руб.", max_digits=10, decimal_places=2, default=0)
    total_copies = models.PositiveIntegerField("Всего экземпляров", default=1)
    available_copies = models.PositiveIntegerField("Доступно экземпляров", default=1)
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.AVAILABLE,
        db_index=True,
    )
    description = models.TextField("Описание", blank=True)
    created_at = models.DateTimeField("Добавлена", default=timezone.now, editable=False)

    class Meta:
        verbose_name = "Книга"
        verbose_name_plural = "Книги"
        ordering = ["title"]
        indexes = [models.Index(fields=["title"], name="book_title_idx")]

    def __str__(self):
        return f"{self.title} — {self.author}"

    def save(self, *args, **kwargs):
        # Доступных экземпляров не может быть больше, чем всего.
        if self.available_copies > self.total_copies:
            self.available_copies = self.total_copies
        self.recalc_status(save=False)
        super().save(*args, **kwargs)

    def recalc_status(self, save=False):
        """Пересчитать статус по количеству доступных экземпляров."""
        if self.available_copies <= 0:
            new_status = self.Status.OUT
        elif self.available_copies <= self.LOW_STOCK_THRESHOLD:
            new_status = self.Status.LIMITED
        else:
            new_status = self.Status.AVAILABLE
        changed = new_status != self.status
        self.status = new_status
        if save and self.pk and changed:
            Book.objects.filter(pk=self.pk).update(status=new_status)
        return self.status

    @property
    def issued_copies(self):
        return max(self.total_copies - self.available_copies, 0)

    @property
    def is_available(self):
        return self.available_copies > 0
