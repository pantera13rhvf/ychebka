from rest_framework import serializers

from .models import Author, Book, Category


class AuthorSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    books_count = serializers.IntegerField(source="books.count", read_only=True)

    class Meta:
        model = Author
        fields = ("id", "first_name", "last_name", "country", "full_name", "books_count")


class CategorySerializer(serializers.ModelSerializer):
    books_count = serializers.IntegerField(source="books.count", read_only=True)

    class Meta:
        model = Category
        fields = ("id", "name", "slug", "books_count")


class BookSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source="author.__str__", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    issued_copies = serializers.IntegerField(read_only=True)
    is_available = serializers.BooleanField(read_only=True)

    class Meta:
        model = Book
        fields = (
            "id",
            "title",
            "isbn",
            "author",
            "author_name",
            "category",
            "category_name",
            "publisher",
            "year",
            "pages",
            "price",
            "total_copies",
            "available_copies",
            "issued_copies",
            "is_available",
            "status",
            "status_display",
            "description",
            "created_at",
        )
        read_only_fields = ("id", "status", "created_at")

    def validate(self, attrs):
        total = attrs.get("total_copies", getattr(self.instance, "total_copies", 0))
        available = attrs.get(
            "available_copies", getattr(self.instance, "available_copies", total)
        )
        if total < 1:
            raise serializers.ValidationError(
                {"total_copies": "Всего экземпляров должно быть не меньше 1."}
            )
        if available > total:
            raise serializers.ValidationError(
                {"available_copies": "Доступных экземпляров не может быть больше общего числа."}
            )
        if available < 0:
            raise serializers.ValidationError(
                {"available_copies": "Количество доступных экземпляров не может быть отрицательным."}
            )
        return attrs


class BookStatusSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    title = serializers.CharField(read_only=True)
    status = serializers.CharField(read_only=True)
    status_display = serializers.CharField(read_only=True)
    total_copies = serializers.IntegerField(read_only=True)
    available_copies = serializers.IntegerField(read_only=True)
    issued_copies = serializers.IntegerField(read_only=True)
