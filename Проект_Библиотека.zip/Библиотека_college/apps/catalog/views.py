from django_filters import rest_framework as filters
from rest_framework import filters as drf_filters
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Author, Book, Category
from .serializers import AuthorSerializer, BookSerializer, BookStatusSerializer, CategorySerializer


class AuthorViewSet(viewsets.ModelViewSet):
    """CRUD по авторам: /api/authors/."""

    queryset = Author.objects.all()
    serializer_class = AuthorSerializer
    filterset_fields = ("country",)
    search_fields = ("first_name", "last_name", "country")
    ordering_fields = ("last_name", "first_name")
    ordering = ("last_name",)


class CategoryViewSet(viewsets.ModelViewSet):
    """CRUD по категориям: /api/categories/."""

    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    search_fields = ("name",)
    ordering_fields = ("name",)
    ordering = ("name",)


class BookViewSet(viewsets.ModelViewSet):
    """Книжный фонд: /api/books/ с фильтрами и поиском."""

    queryset = Book.objects.select_related("author", "category").all()
    serializer_class = BookSerializer
    filterset_fields = ("status", "category", "author")
    search_fields = ("title", "isbn", "author__last_name", "author__first_name")
    ordering_fields = ("title", "year", "price", "created_at")
    ordering = ("title",)
    filter_backends = (
        filters.DjangoFilterBackend,
        drf_filters.SearchFilter,
        drf_filters.OrderingFilter,
    )

    @action(detail=True, methods=["get"], url_path="status")
    def status(self, request, pk=None):
        """GET /api/books/{id}/status/ — актуальный статус экземпляров."""
        book = self.get_object()
        book.recalc_status(save=True)
        data = BookStatusSerializer(
            {
                "id": book.id,
                "title": book.title,
                "status": book.status,
                "status_display": book.get_status_display(),
                "total_copies": book.total_copies,
                "available_copies": book.available_copies,
                "issued_copies": book.issued_copies,
            }
        )
        return Response(data.data)
