from django.contrib import admin

from .models import Author, Book, Category


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ("last_name", "first_name", "country", "books_count")
    list_filter = ("country",)
    search_fields = ("first_name", "last_name", "country")
    ordering = ("last_name", "first_name")

    @admin.display(description="Книг в фонде")
    def books_count(self, obj):
        return obj.books.count()


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "books_count")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}

    @admin.display(description="Книг в категории")
    def books_count(self, obj):
        return obj.books.count()


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "author",
        "category",
        "total_copies",
        "available_copies",
        "status",
    )
    list_editable = ("available_copies", "status")
    list_filter = ("status", "category", "author", "year")
    search_fields = ("title", "isbn", "author__last_name", "publisher")
    list_select_related = ("author", "category")
    readonly_fields = ("created_at", "issued_copies")
    autocomplete_fields = ("author",)
    fieldsets = (
        ("Основные сведения", {"fields": ("title", "isbn", "author", "category")}),
        (
            "Издание",
            {"fields": ("publisher", "year", "pages", "price", "description")},
        ),
        (
            "Фонд",
            {"fields": ("total_copies", "available_copies", "issued_copies", "status", "created_at")},
        ),
    )
    ordering = ("title",)
