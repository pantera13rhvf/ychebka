from django.conf import settings
from django.db import models
from django.utils import timezone


class Reader(models.Model):
    """Читатель библиотеки колледжа."""

    full_name = models.CharField("ФИО", max_length=150, db_index=True)
    ticket_number = models.CharField("Номер билета", max_length=30, unique=True)
    phone = models.CharField("Телефон", max_length=20, blank=True)
    email = models.EmailField("E-mail", blank=True)
    birth_date = models.DateField("Дата рождения", null=True, blank=True)
    registered_at = models.DateTimeField("Дата регистрации", default=timezone.now, editable=False)
    is_blocked = models.BooleanField("Заблокирован", default=False)
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Ответственный сотрудник",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="readers",
    )

    class Meta:
        verbose_name = "Читатель"
        verbose_name_plural = "Читатели"
        ordering = ["full_name"]
        indexes = [models.Index(fields=["full_name"], name="reader_name_idx")]

    def __str__(self):
        return f"{self.full_name} ({self.ticket_number})"

    @property
    def active_loans_count(self):
        return self.loans.filter(returned_at__isnull=True).count()

    @property
    def has_overdue(self):
        return self.loans.filter(
            returned_at__isnull=True, due_date__lt=timezone.localdate()
        ).exists()
