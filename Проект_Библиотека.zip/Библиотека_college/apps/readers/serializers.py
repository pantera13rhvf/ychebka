from rest_framework import serializers

from .models import Reader


class ReaderSerializer(serializers.ModelSerializer):
    manager_name = serializers.CharField(source="manager.__str__", read_only=True, default="")
    active_loans_count = serializers.IntegerField(read_only=True)
    has_overdue = serializers.BooleanField(read_only=True)

    class Meta:
        model = Reader
        fields = (
            "id",
            "full_name",
            "ticket_number",
            "phone",
            "email",
            "birth_date",
            "registered_at",
            "is_blocked",
            "manager",
            "manager_name",
            "active_loans_count",
            "has_overdue",
        )
        read_only_fields = ("id", "registered_at")

    def validate_ticket_number(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Номер билета обязателен.")
        return value
