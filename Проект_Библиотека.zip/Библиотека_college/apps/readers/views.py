from django_filters import rest_framework as filters
from rest_framework import filters as drf_filters
from rest_framework import viewsets

from .models import Reader
from .serializers import ReaderSerializer


class ReaderViewSet(viewsets.ModelViewSet):
    """Читатели: /api/readers/."""

    queryset = Reader.objects.select_related("manager").all()
    serializer_class = ReaderSerializer
    filterset_fields = ("is_blocked", "manager")
    search_fields = ("full_name", "ticket_number", "phone", "email")
    ordering_fields = ("full_name", "registered_at")
    ordering = ("full_name",)
    filter_backends = (
        filters.DjangoFilterBackend,
        drf_filters.SearchFilter,
        drf_filters.OrderingFilter,
    )
