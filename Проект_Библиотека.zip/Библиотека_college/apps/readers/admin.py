from django.contrib import admin

from .models import Reader


@admin.register(Reader)
class ReaderAdmin(admin.ModelAdmin):
    list_display = (
        "full_name",
        "ticket_number",
        "phone",
        "email",
        "is_blocked",
        "active_loans_count",
        "manager",
    )
    list_editable = ("is_blocked",)
    list_filter = ("is_blocked", "registered_at", "manager")
    search_fields = ("full_name", "ticket_number", "phone", "email")
    autocomplete_fields = ("manager",)
    readonly_fields = ("registered_at",)
    date_hierarchy = "registered_at"
    list_select_related = ("manager",)

    @admin.display(description="На руках")
    def active_loans_count(self, obj):
        return obj.active_loans_count
