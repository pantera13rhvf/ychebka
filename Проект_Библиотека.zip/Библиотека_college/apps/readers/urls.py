from rest_framework.routers import DefaultRouter

from .views import ReaderViewSet

app_name = "readers"

router = DefaultRouter()
router.register("readers", ReaderViewSet, basename="reader")

urlpatterns = router.urls
