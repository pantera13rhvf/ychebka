from datetime import timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.utils import timezone

from apps.catalog.models import Book
from apps.readers.models import Reader

DEFAULT_LOAN_DAYS = 14


class LoanQuerySet(models.QuerySet):
    def active(self):
        return self.filter(returned_at__isnull=True)

    def overdue(self):
        return self.active().filter(due_date__lt=timezone.localdate())

    def mark_overdue(self):
        """Проставить статус «Просрочена» активным выдачам с истёкшим сроком."""
        return self.filter(
            status=Loan.Status.ACTIVE,
            returned_at__isnull=True,
            due_date__lt=timezone.localdate(),
        ).update(status=Loan.Status.OVERDUE)


class Loan(models.Model):
    """Выдача книги читателю."""

    class Status(models.TextChoices):
        ACTIVE = "active", "Выдана"
        RETURNED = "returned", "Возвращена"
        OVERDUE = "overdue", "Просрочена"

    reader = models.ForeignKey(
        Reader,
        verbose_name="Читатель",
        on_delete=models.CASCADE,
        related_name="loans",
    )
    book = models.ForeignKey(
        Book,
        verbose_name="Книга",
        on_delete=models.PROTECT,
        related_name="loans",
    )
    issued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Выдал сотрудник",
        on_delete=models.PROTECT,
        related_name="issued_loans",
    )
    issued_at = models.DateTimeField("Дата выдачи", default=timezone.now)
    due_date = models.DateField("Вернуть до")
    returned_at = models.DateTimeField("Дата возврата", null=True, blank=True)
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.ACTIVE,
        db_index=True,
    )
    comment = models.CharField("Комментарий", max_length=255, blank=True)

    objects = LoanQuerySet.as_manager()

    class Meta:
        verbose_name = "Выдача"
        verbose_name_plural = "Выдачи"
        ordering = ["-issued_at"]
        indexes = [
            models.Index(fields=["status"], name="loan_status_idx"),
            models.Index(fields=["due_date"], name="loan_due_idx"),
        ]

    def __str__(self):
        return f"{self.book.title} → {self.reader.full_name}"

    def save(self, *args, **kwargs):
        if not self.due_date:
            self.due_date = timezone.localdate() + timedelta(days=DEFAULT_LOAN_DAYS)
        super().save(*args, **kwargs)

    def clean(self):
        if self.book_id and self.available_copies_are_missing_for_issue():
            raise ValidationError({"book": "Нет доступных экземпляров книги."})

    def available_copies_are_missing_for_issue(self):
        return self.book.available_copies <= 0

    def issue(self):
        """Выдать книгу: списать экземпляр из фонда и отметить выдачу активной."""
        if not self.pk:
            raise ValidationError("Сначала сохраните выдачу.")
        if self.returned_at:
            raise ValidationError("Книга уже возвращена — повторная выдача невозможна.")

        with transaction.atomic():
            book = Book.objects.select_for_update().get(pk=self.book_id)
            if book.available_copies <= 0:
                raise ValidationError("Нет доступных экземпляров книги.")
            book.available_copies -= 1
            book.recalc_status(save=False)
            book.save(update_fields=["available_copies", "status"])

            self.status = self.Status.ACTIVE
            self.returned_at = None
            self.save(update_fields=["status", "returned_at"])

        self.refresh_from_db()
        return self

    def return_book(self):
        """Вернуть книгу: вернуть экземпляр в фонд и закрыть выдачу."""
        if not self.pk:
            raise ValidationError("Сначала сохраните выдачу.")
        if self.returned_at or self.status == self.Status.RETURNED:
            raise ValidationError("Эта выдача уже закрыта.")

        with transaction.atomic():
            book = Book.objects.select_for_update().get(pk=self.book_id)
            book.available_copies = min(book.available_copies + 1, book.total_copies)
            book.recalc_status(save=False)
            book.save(update_fields=["available_copies", "status"])

            self.returned_at = timezone.now()
            self.status = self.Status.RETURNED
            self.save(update_fields=["status", "returned_at"])

        self.refresh_from_db()
        return self

    @property
    def is_overdue(self):
        """Просрочена ли выдача (для возвращённых — был ли нарушен срок)."""
        if not self.due_date:
            return False
        control_date = self.returned_at.date() if self.returned_at else timezone.localdate()
        return control_date > self.due_date

    @property
    def days_overdue(self):
        if not self.is_overdue:
            return 0
        control_date = self.returned_at.date() if self.returned_at else timezone.localdate()
        return (control_date - self.due_date).days

    @property
    def is_active(self):
        return self.returned_at is None
