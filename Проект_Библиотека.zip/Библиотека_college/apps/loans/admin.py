from django.contrib import admin, messages

from .models import Loan


@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "reader",
        "book",
        "issued_at",
        "due_date",
        "returned_at",
        "status",
        "issued_by",
    )
    list_filter = ("status", "issued_at", "due_date", "issued_by")
    search_fields = (
        "reader__full_name",
        "reader__ticket_number",
        "book__title",
        "book__isbn",
    )
    date_hierarchy = "issued_at"
    list_select_related = ("reader", "book", "issued_by")
    readonly_fields = ("returned_at",)
    actions = ("mark_returned",)

    @admin.action(description="Отметить возврат")
    def mark_returned(self, request, queryset):
        """Вернуть в фонд выбранные выдачи и закрыть их."""
        returned, skipped = 0, 0
        for loan in queryset.select_related("book"):
            if loan.returned_at:
                skipped += 1
                continue
            loan.return_book()
            returned += 1
        if returned:
            self.message_user(
                request,
                f"Отмечено возвратов: {returned}.",
                level=messages.SUCCESS,
            )
        if skipped:
            self.message_user(
                request,
                f"Пропущено уже закрытых выдач: {skipped}.",
                level=messages.WARNING,
            )

    @admin.display(description="Просрочена", boolean=True)
    def overdue_flag(self, obj):
        return obj.is_overdue
