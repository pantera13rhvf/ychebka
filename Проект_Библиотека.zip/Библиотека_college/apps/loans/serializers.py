from datetime import timedelta

from django.utils import timezone
from rest_framework import serializers

from apps.catalog.models import Book
from apps.readers.models import Reader

from .models import DEFAULT_LOAN_DAYS, Loan


class LoanSerializer(serializers.ModelSerializer):
    reader_name = serializers.CharField(source="reader.full_name", read_only=True)
    ticket_number = serializers.CharField(source="reader.ticket_number", read_only=True)
    book_title = serializers.CharField(source="book.title", read_only=True)
    book_isbn = serializers.CharField(source="book.isbn", read_only=True)
    issued_by_name = serializers.CharField(source="issued_by.__str__", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    is_overdue = serializers.BooleanField(read_only=True)
    days_overdue = serializers.IntegerField(read_only=True)

    class Meta:
        model = Loan
        fields = (
            "id",
            "reader",
            "reader_name",
            "ticket_number",
            "book",
            "book_title",
            "book_isbn",
            "issued_by",
            "issued_by_name",
            "issued_at",
            "due_date",
            "returned_at",
            "status",
            "status_display",
            "is_overdue",
            "days_overdue",
            "comment",
        )
        read_only_fields = (
            "id",
            "issued_by",
            "issued_at",
            "returned_at",
            "status",
            "is_overdue",
            "days_overdue",
        )
        extra_kwargs = {
            "due_date": {"required": False},
        }

    def validate_reader(self, reader: Reader):
        if reader.is_blocked:
            raise serializers.ValidationError(
                "Читатель заблокирован — выдача невозможна."
            )
        return reader

    def validate_book(self, book: Book):
        if book.available_copies <= 0:
            raise serializers.ValidationError(
                "Нет доступных экземпляров книги."
            )
        return book

    def validate_due_date(self, value):
        if value < timezone.localdate():
            raise serializers.ValidationError(
                "Срок возврата не может быть раньше сегодняшнего дня."
            )
        return value

    def validate(self, attrs):
        due_date = attrs.get("due_date")
        if due_date is None:
            attrs["due_date"] = timezone.localdate() + timedelta(days=DEFAULT_LOAN_DAYS)
        return attrs


class ReturnSerializer(serializers.Serializer):
    comment = serializers.CharField(required=False, allow_blank=True, max_length=255)
