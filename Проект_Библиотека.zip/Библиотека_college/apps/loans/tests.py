from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.catalog.models import Author, Book, Category
from apps.readers.models import Reader

from .models import Loan


class LoanTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.librarian = User.objects.create_user(
            username="librarian",
            password="library2024",
            full_name="Соколова Анна Викторовна",
            position=User.Position.LIBRARIAN,
        )
        cls.author = Author.objects.create(first_name="Лев", last_name="Толстой", country="Россия")
        cls.category = Category.objects.create(name="Русская классика", slug="russkaya-klassika")
        cls.book = Book.objects.create(
            title="Война и мир",
            isbn="978-5-04-000000-1",
            author=cls.author,
            category=cls.category,
            publisher="Эксмо",
            year=2021,
            pages=704,
            price=Decimal("890.00"),
            total_copies=3,
            available_copies=3,
        )
        cls.reader = Reader.objects.create(
            full_name="Иванова Мария Сергеевна",
            ticket_number="Ч-2024-001",
            phone="+7 (900) 111-22-33",
            manager=cls.librarian,
        )

    def make_loan(self, **overrides):
        data = {
            "reader": self.reader,
            "book": self.book,
            "issued_by": self.librarian,
            "due_date": timezone.localdate() + timedelta(days=14),
        }
        data.update(overrides)
        return Loan.objects.create(**data)


class LoanModelTests(LoanTestCase):
    def test_issue_decreases_available_copies(self):
        """Выдача уменьшает количество доступных экземпляров."""
        loan = self.make_loan()
        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 3, "Создание записи не должно менять фонд")

        loan.issue()

        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 2)
        self.assertEqual(loan.status, Loan.Status.ACTIVE)
        self.assertIsNone(loan.returned_at)
        self.assertEqual(self.book.issued_copies, 1)

    def test_return_increases_available_copies(self):
        """Возврат увеличивает количество доступных экземпляров и закрывает выдачу."""
        loan = self.make_loan()
        loan.issue()
        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 2)

        loan.return_book()

        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 3)
        self.assertEqual(loan.status, Loan.Status.RETURNED)
        self.assertIsNotNone(loan.returned_at)

    def test_cannot_issue_when_no_copies_available(self):
        """Нельзя выдать книгу, если доступных экземпляров нет."""
        self.book.available_copies = 0
        self.book.save()
        loan = self.make_loan()

        with self.assertRaises(ValidationError):
            loan.issue()

        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 0)
        self.assertEqual(self.book.status, Book.Status.OUT)

    def test_book_status_recalculated(self):
        """Статус книги пересчитывается по остатку экземпляров."""
        book = Book.objects.create(
            title="Собачье сердце",
            isbn="978-5-04-000000-2",
            author=self.author,
            category=self.category,
            total_copies=3,
            available_copies=3,
            year=2021,
            pages=256,
            price=Decimal("340.00"),
        )
        self.assertEqual(book.status, Book.Status.AVAILABLE)

        first = self.make_loan(book=book)
        first.issue()
        book.refresh_from_db()
        self.assertEqual(book.available_copies, 2)
        self.assertEqual(book.status, Book.Status.LIMITED)

        second = self.make_loan(book=book)
        second.issue()
        book.refresh_from_db()
        self.assertEqual(book.status, Book.Status.LIMITED)

        third = self.make_loan(book=book)
        third.issue()
        book.refresh_from_db()
        self.assertEqual(book.available_copies, 0)
        self.assertEqual(book.status, Book.Status.OUT)

        first.return_book()
        book.refresh_from_db()
        self.assertEqual(book.available_copies, 1)
        self.assertEqual(book.status, Book.Status.LIMITED)

    def test_overdue_property_for_active_loan(self):
        """Просрочка определяется по сроку возврата."""
        overdue_loan = self.make_loan(due_date=timezone.localdate() - timedelta(days=3))
        self.assertTrue(overdue_loan.is_overdue)
        self.assertEqual(overdue_loan.days_overdue, 3)

        fresh_loan = self.make_loan(
            book=self.book,
            due_date=timezone.localdate() + timedelta(days=5),
        )
        self.assertFalse(fresh_loan.is_overdue)
        self.assertEqual(fresh_loan.days_overdue, 0)

    def test_returned_loan_overdue_flag_uses_return_date(self):
        """Для возвращённой книги просрочка фиксируется, если срок был нарушен."""
        loan = self.make_loan(due_date=timezone.localdate() - timedelta(days=10))
        loan.issue()
        loan.return_book()
        self.assertTrue(loan.is_overdue)

        on_time = self.make_loan(due_date=timezone.localdate() + timedelta(days=2))
        on_time.issue()
        on_time.return_book()
        self.assertFalse(on_time.is_overdue)

    def test_double_return_raises_error(self):
        """Повторный возврат невозможен — фонд не удваивается."""
        loan = self.make_loan()
        loan.issue()
        loan.return_book()

        with self.assertRaises(ValidationError):
            loan.return_book()

        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 3)

    def test_return_never_exceeds_total_copies(self):
        """Возврат не может сделать доступных экземпляров больше, чем всего."""
        loan = self.make_loan()
        loan.issue()
        Book.objects.filter(pk=self.book.pk).update(available_copies=self.book.total_copies)

        loan.return_book()

        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, self.book.total_copies)

    def test_mark_overdue_queryset_updates_status(self):
        """Менеджер запросов переводит просроченные выдачи в статус «Просрочена»."""
        loan = self.make_loan(due_date=timezone.localdate() - timedelta(days=2))
        loan.issue()
        self.assertEqual(loan.status, Loan.Status.ACTIVE)

        updated = Loan.objects.mark_overdue()

        loan.refresh_from_db()
        self.assertGreaterEqual(updated, 1)
        self.assertEqual(loan.status, Loan.Status.OVERDUE)


class LoanApiTests(LoanTestCase):
    def setUp(self):
        self.client = APIClient()
        self.client.force_authenticate(user=self.librarian)

    def test_create_loan_via_api_issues_book(self):
        """POST /api/loans/ создаёт выдачу, списывая экземпляр из фонда."""
        response = self.client.post(
            "/api/loans/",
            {"reader": self.reader.pk, "book": self.book.pk, "comment": "Выдана на семестр"},
            format="json",
        )

        self.assertEqual(response.status_code, 201, response.content)
        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 2)
        self.assertEqual(response.json()["status"], Loan.Status.ACTIVE)
        self.assertEqual(Loan.objects.count(), 1)

    def test_create_loan_without_copies_returns_400(self):
        """При нулевом остатке API возвращает 400 и не создаёт выдачу."""
        self.book.available_copies = 0
        self.book.save()

        response = self.client.post(
            "/api/loans/",
            {"reader": self.reader.pk, "book": self.book.pk},
            format="json",
        )

        self.assertEqual(response.status_code, 400, response.content)
        self.assertEqual(Loan.objects.count(), 0)

    def test_return_loan_via_api(self):
        """POST /api/loans/{id}/return/ возвращает книгу в фонд."""
        loan = self.make_loan()
        loan.issue()

        response = self.client.post(f"/api/loans/{loan.pk}/return/", {}, format="json")

        self.assertEqual(response.status_code, 200, response.content)
        self.book.refresh_from_db()
        loan.refresh_from_db()
        self.assertEqual(self.book.available_copies, 3)
        self.assertEqual(loan.status, Loan.Status.RETURNED)

    def test_loans_require_authentication(self):
        """Без JWT-токена список выдач недоступен."""
        anonymous = APIClient()
        response = anonymous.get("/api/loans/")
        self.assertEqual(response.status_code, 401)


class LoanAdminTests(LoanTestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(
            username="admin",
            password="admin12345",
            email="admin@college.ru",
            full_name="Администратор библиотеки",
        )
        self.client.login(username="admin", password="admin12345")

    def test_admin_index_uses_library_titles(self):
        """Заголовки админки настроены под библиотеку."""
        response = self.client.get("/admin/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Библиотека колледжа: администрирование")

    def test_admin_book_changelist(self):
        """Список книг в админке доступен и содержит издание."""
        response = self.client.get("/admin/catalog/book/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Война и мир")

    def test_admin_mark_returned_action(self):
        """Действие «Отметить возврат» закрывает выдачу и возвращает экземпляр."""
        loan = self.make_loan()
        loan.issue()
        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 2)

        response = self.client.post(
            "/admin/loans/loan/",
            {
                "action": "mark_returned",
                "_selected_action": [str(loan.pk)],
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        loan.refresh_from_db()
        self.book.refresh_from_db()
        self.assertEqual(loan.status, Loan.Status.RETURNED)
        self.assertIsNotNone(loan.returned_at)
        self.assertEqual(self.book.available_copies, 3)
