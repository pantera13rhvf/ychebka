from django.core.exceptions import ValidationError as DjangoValidationError
from django.utils import timezone
from django_filters import rest_framework as filters
from rest_framework import filters as drf_filters
from rest_framework import serializers, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Loan
from .serializers import LoanSerializer, ReturnSerializer


class LoanFilter(filters.FilterSet):
    overdue = filters.BooleanFilter(method="filter_overdue", label="Только просроченные")

    class Meta:
        model = Loan
        fields = ("status", "reader", "book", "issued_by", "overdue")

    def filter_overdue(self, queryset, name, value):
        if value:
            return queryset.filter(
                returned_at__isnull=True, due_date__lt=timezone.localdate()
            )
        return queryset


class LoanViewSet(viewsets.ModelViewSet):
    """Выдачи книг: /api/loans/."""

    queryset = Loan.objects.select_related("reader", "book", "issued_by").all()
    serializer_class = LoanSerializer
    filterset_class = LoanFilter
    search_fields = ("reader__full_name", "book__title", "book__isbn")
    ordering_fields = ("issued_at", "due_date", "returned_at")
    ordering = ("-issued_at",)
    filter_backends = (
        filters.DjangoFilterBackend,
        drf_filters.SearchFilter,
        drf_filters.OrderingFilter,
    )

    def get_queryset(self):
        Loan.objects.mark_overdue()
        return super().get_queryset()

    def perform_create(self, serializer):
        loan = serializer.save(issued_by=self.request.user)
        try:
            loan.issue()
        except DjangoValidationError as exc:
            loan.delete()
            raise serializers.ValidationError({"book": exc.messages})

    def perform_update(self, serializer):
        loan = self.get_object()
        if loan.returned_at:
            raise serializers.ValidationError(
                {"detail": "Закрытую выдачу изменять нельзя."}
            )
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        loan = self.get_object()
        if loan.returned_at is None:
            raise serializers.ValidationError(
                {"detail": "Нельзя удалить активную выдачу — сначала отметьте возврат."}
            )
        return super().destroy(request, *args, **kwargs)

    @action(detail=True, methods=["post"], url_path="return")
    def return_book(self, request, pk=None):
        """POST /api/loans/{id}/return/ — отметить возврат книги."""
        loan = self.get_object()
        payload = ReturnSerializer(data=request.data)
        payload.is_valid(raise_exception=True)
        comment = payload.validated_data.get("comment")
        try:
            loan.return_book()
        except DjangoValidationError as exc:
            return Response(
                {"detail": exc.messages[0] if exc.messages else "Ошибка возврата."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if comment:
            loan.comment = comment
            loan.save(update_fields=["comment"])
        return Response(LoanSerializer(loan).data, status=status.HTTP_200_OK)
