"""Демонстрационные данные для проекта «Библиотека колледжа».

Запуск:  python seed.py
Скрипт идемпотентен: повторный запуск не создаёт дубликатов.
"""
import os
import sys
from datetime import timedelta
from decimal import Decimal

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from django.db import transaction  # noqa: E402
from django.utils import timezone  # noqa: E402

from apps.accounts.models import User  # noqa: E402
from apps.catalog.models import Author, Book, Category  # noqa: E402
from apps.loans.models import Loan  # noqa: E402
from apps.readers.models import Reader  # noqa: E402

ADMIN_PASSWORD = "admin12345"
STAFF_PASSWORD = "library2024"

AUTHORS = [
    ("Лев", "Толстой", "Россия"),
    ("Фёдор", "Достоевский", "Россия"),
    ("Михаил", "Булгаков", "Россия"),
    ("Александр", "Пушкин", "Россия"),
    ("Михаил", "Лермонтов", "Россия"),
    ("Джордж", "Оруэлл", "Великобритания"),
    ("Аркадий", "Стругацкий", "Россия"),
    ("Игорь", "Иванов", "Россия"),
]

CATEGORIES = [
    ("Русская классика", "russkaya-klassika"),
    ("Зарубежная проза", "zarubezhnaya-proza"),
    ("Фантастика", "fantastika"),
    ("Учебная литература", "uchebnaya-literatura"),
]

# (title, isbn, автор_индекс, категория_slug, издательство, год, страниц, цена, всего)
BOOKS = [
    ("Война и мир. Том 1", "978-5-04-118601-1", 0, "russkaya-klassika", "Эксмо", 2021, 704, "890.00", 5),
    ("Анна Каренина", "978-5-04-118602-8", 0, "russkaya-klassika", "Эксмо", 2020, 864, "760.00", 3),
    ("Преступление и наказание", "978-5-04-118603-5", 1, "russkaya-klassika", "АСТ", 2019, 672, "650.00", 4),
    ("Братья Карамазовы", "978-5-04-118604-2", 1, "russkaya-klassika", "АСТ", 2018, 832, "720.00", 3),
    ("Мастер и Маргарита", "978-5-04-118605-9", 2, "russkaya-klassika", "Азбука", 2022, 480, "590.00", 6),
    ("Собачье сердце", "978-5-04-118606-6", 2, "russkaya-klassika", "Азбука", 2021, 256, "340.00", 2),
    ("Евгений Онегин", "978-5-04-118607-3", 3, "russkaya-klassika", "Детская литература", 2020, 320, "410.00", 4),
    ("Капитанская дочка", "978-5-04-118608-0", 3, "russkaya-klassika", "Детская литература", 2019, 288, "380.00", 3),
    ("Герой нашего времени", "978-5-04-118609-7", 4, "russkaya-klassika", "Эксмо", 2020, 224, "350.00", 2),
    ("1984", "978-5-04-118610-3", 5, "zarubezhnaya-proza", "АСТ", 2022, 320, "520.00", 5),
    ("Скотный двор", "978-5-04-118611-0", 5, "zarubezhnaya-proza", "АСТ", 2021, 192, "390.00", 2),
    ("Понедельник начинается в субботу", "978-5-04-118612-7", 6, "fantastika", "СПб: Азбука", 2020, 416, "610.00", 3),
    ("Трудно быть богом", "978-5-04-118613-4", 6, "fantastika", "СПб: Азбука", 2019, 384, "580.00", 2),
    (
        "Библиотечное дело: организация и управление",
        "978-5-04-118614-1",
        7,
        "uchebnaya-literatura",
        "Юрайт",
        2023,
        352,
        "1290.00",
        4,
    ),
]

READERS = [
    ("Иванова Мария Сергеевна", "Ч-2024-001", "+7 (900) 111-22-33", "ivanova@college.ru", "2006-03-14"),
    ("Петров Алексей Николаевич", "Ч-2024-002", "+7 (900) 222-33-44", "petrov@college.ru", "2005-11-02"),
    ("Сидорова Екатерина Павловна", "Ч-2024-003", "+7 (900) 333-44-55", "sidorova@college.ru", "2006-07-21"),
    ("Кузнецов Дмитрий Андреевич", "Ч-2024-004", "+7 (900) 444-55-66", "kuznetsov@college.ru", "2005-01-30"),
    ("Смирнова Ольга Игоревна", "Ч-2024-005", "+7 (900) 555-66-77", "smirnova@college.ru", "2006-09-09"),
    ("Морозов Никита Владимирович", "Ч-2024-006", "+7 (900) 666-77-88", "morozov@college.ru", "2004-12-17"),
]

# (индекс_читателя, индекс_книги, выдана_дней_назад, вернуть_через_дней, возвращена_дней_назад)
LOANS = [
    (0, 0, 25, -11, None),   # активная, просроченная
    (1, 4, 10, 4, None),     # активная
    (2, 9, 20, 5, None),     # активная
    (3, 6, 3, 11, None),     # активная
    (4, 11, 1, 13, None),    # активная
    (5, 2, 40, -26, 30),     # возвращена (в срок)
    (0, 10, 60, -46, 45),    # возвращена (в срок)
    (2, 5, 15, -1, 2),       # возвращена с небольшим опозданием
]


def ensure_users():
    admin, created = User.objects.get_or_create(
        username="admin",
        defaults={
            "full_name": "Администратор библиотеки",
            "position": User.Position.ADMIN,
            "phone": "+7 (495) 000-00-01",
            "email": "admin@college.ru",
            "is_staff": True,
            "is_superuser": True,
        },
    )
    if created:
        admin.set_password(ADMIN_PASSWORD)
        admin.save(update_fields=["password"])

    librarian, created = User.objects.get_or_create(
        username="librarian",
        defaults={
            "full_name": "Соколова Анна Викторовна",
            "position": User.Position.LIBRARIAN,
            "phone": "+7 (495) 000-00-02",
            "email": "sokolova@college.ru",
            "is_staff": True,
        },
    )
    if created:
        librarian.set_password(STAFF_PASSWORD)
        librarian.save(update_fields=["password"])

    manager, created = User.objects.get_or_create(
        username="manager",
        defaults={
            "full_name": "Кузнецова Ирина Петровна",
            "position": User.Position.MANAGER,
            "phone": "+7 (495) 000-00-03",
            "email": "kuznetsova@college.ru",
            "is_staff": True,
        },
    )
    if created:
        manager.set_password(STAFF_PASSWORD)
        manager.save(update_fields=["password"])

    return admin, librarian, manager


def ensure_authors():
    authors = []
    for first_name, last_name, country in AUTHORS:
        author, _ = Author.objects.get_or_create(
            first_name=first_name,
            last_name=last_name,
            defaults={"country": country},
        )
        authors.append(author)
    return authors


def ensure_categories():
    categories = {}
    for name, slug in CATEGORIES:
        category, _ = Category.objects.get_or_create(slug=slug, defaults={"name": name})
        categories[slug] = category
    return categories


def ensure_books(authors, categories):
    books = []
    for title, isbn, author_idx, category_slug, publisher, year, pages, price, total in BOOKS:
        book, _ = Book.objects.get_or_create(
            isbn=isbn,
            defaults={
                "title": title,
                "author": authors[author_idx],
                "category": categories[category_slug],
                "publisher": publisher,
                "year": year,
                "pages": pages,
                "price": Decimal(price),
                "total_copies": total,
                "available_copies": total,
                "description": f"Учебное издание из фонда библиотеки колледжа: {title}.",
            },
        )
        books.append(book)
    return books


def ensure_readers(manager):
    readers = []
    for full_name, ticket, phone, email, birth in READERS:
        reader, _ = Reader.objects.get_or_create(
            ticket_number=ticket,
            defaults={
                "full_name": full_name,
                "phone": phone,
                "email": email,
                "birth_date": birth,
                "manager": manager,
            },
        )
        readers.append(reader)
    return readers


@transaction.atomic
def ensure_loans(readers, books, librarian):
    now = timezone.now()
    today = timezone.localdate()
    created_count = 0

    for index, (reader_idx, book_idx, issued_days, due_days, returned_days) in enumerate(LOANS, start=1):
        marker = f"seed-{index:02d}"
        if Loan.objects.filter(comment=marker).exists():
            continue

        issued_at = now - timedelta(days=issued_days)
        due_date = today + timedelta(days=due_days)
        returned_at = now - timedelta(days=returned_days) if returned_days is not None else None
        status = Loan.Status.RETURNED if returned_at else Loan.Status.ACTIVE
        if returned_at is None and due_date < today:
            status = Loan.Status.OVERDUE

        Loan.objects.create(
            reader=readers[reader_idx],
            book=books[book_idx],
            issued_by=librarian,
            issued_at=issued_at,
            due_date=due_date,
            returned_at=returned_at,
            status=status,
            comment=marker,
        )
        created_count += 1

    return created_count


def sync_available_copies(books):
    """Привести available_copies и статус книг в соответствие с открытыми выдачами."""
    for book in books:
        active = book.loans.filter(returned_at__isnull=True).count()
        book.available_copies = max(book.total_copies - active, 0)
        book.recalc_status(save=False)
        book.save(update_fields=["available_copies", "status"])


def main():
    print("Наполнение базы демонстрационными данными...")
    admin, librarian, manager = ensure_users()
    authors = ensure_authors()
    categories = ensure_categories()
    books = ensure_books(authors, categories)
    readers = ensure_readers(manager)
    loans_created = ensure_loans(readers, books, librarian)
    sync_available_copies(books)

    print(f"  Сотрудники: {User.objects.count()} (admin, librarian, manager)")
    print(f"  Авторы: {len(authors)}")
    print(f"  Категории: {len(categories)}")
    print(f"  Книги: {len(books)}, экземпляров: {sum(b.total_copies for b in books)}")
    print(f"  Читатели: {len(readers)}")
    print(f"  Выдачи: {Loan.objects.count()} (создано сейчас: {loans_created})")
    print(
        "  Активных: {0}, просроченных: {1}, возвращено: {2}".format(
            Loan.objects.filter(returned_at__isnull=True).count(),
            Loan.objects.filter(returned_at__isnull=True, due_date__lt=timezone.localdate()).count(),
            Loan.objects.filter(returned_at__isnull=False).count(),
        )
    )
    print()
    print("Готово. Доступ в админку: admin / admin12345")
    print("Сотрудники: librarian / library2024, manager / library2024")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print(f"Ошибка наполнения: {exc}", file=sys.stderr)
        raise
