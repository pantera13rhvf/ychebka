"""Корневая маршрутизация проекта «Библиотека колледжа»."""
from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path
from django.views.decorators.http import require_GET

admin.site.site_header = "Библиотека колледжа: администрирование"
admin.site.site_title = "Библиотека колледжа"
admin.site.index_title = "Управление книжным фондом и выдачей"


@require_GET
def api_root(request):
    """Краткая карта API — удобно для проверки работоспособности."""
    return JsonResponse(
        {
            "service": "Библиотека колледжа — API",
            "version": "1.0",
            "endpoints": {
                "auth_login": "/api/auth/login/",
                "auth_refresh": "/api/auth/refresh/",
                "auth_me": "/api/auth/me/",
                "books": "/api/books/",
                "book_status": "/api/books/{id}/status/",
                "authors": "/api/authors/",
                "categories": "/api/categories/",
                "readers": "/api/readers/",
                "loans": "/api/loans/",
                "loan_return": "/api/loans/{id}/return/",
                "reports_kpi": "/api/reports/kpi/",
                "reports_issues": "/api/reports/issues/",
                "reports_top_books": "/api/reports/top-books/",
                "reports_stock": "/api/reports/stock/",
                "admin": "/admin/",
            },
        },
        json_dumps_params={"ensure_ascii": False, "indent": 2},
    )


urlpatterns = [
    path("", api_root, name="api-root"),
    path("admin/", admin.site.urls),
    path("api/auth/", include("apps.accounts.urls")),
    path("api/", include("apps.catalog.urls")),
    path("api/", include("apps.readers.urls")),
    path("api/", include("apps.loans.urls")),
    path("api/reports/", include("apps.reports.urls")),
]
